//
//  ViewController.swift
//  Currency conversion App
//
//  Created by Mervat Mustafa on 2020-11-04.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var msg: UITextField!
    @IBOutlet weak var cad: UITextField!
    @IBOutlet weak var amount: UITextField!
    @IBOutlet weak var code: UITextField!
    let rates = ["USD":1.3,"INR":0.018,"EUR":1.54,"JOD":1.85,"AUD":0.94]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func convert(_ sender: Any) {
        if amount.text != ""{
           let money = Double(amount.text!)!
           let exchangeRate = findRate(cd: code.text!)
            if exchangeRate == 0.0 {
                msg.text = "Sorry the currency code is not recognized"
            }
            else {
                msg.text = ""
                let candaidan = money * exchangeRate
                cad.text = String(candaidan.rounded())
            }
            
        }
    }
    func findRate (cd:String) ->Double{
        for cr in rates.keys {
            if cr == cd {
                return rates[cr]!
            }
        }
        return 0.0
    }
    
}

